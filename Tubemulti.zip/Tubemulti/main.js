/**
 * TubeMulti - Multi-Account YouTube Desktop Client for Fedora Linux
 * Main Process File - High-Performance, Scalable & Native Layering Sync
 */

const { app, BrowserWindow, WebContentsView, BrowserView, ipcMain, session, shell, nativeTheme, Menu } = require('electron');
const path = require('path');
const fs = require('fs');

// Enable Dark Mode
nativeTheme.themeSource = 'dark';

// Storage file path
const ACCOUNTS_FILE = path.join(app.getPath('userData'), 'accounts.json');

// Desktop User-Agent string for Google/YouTube auth compatibility
const DESKTOP_USER_AGENT = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36';

let mainWindow = null;
let activeAccountId = null;
let accounts = [];
let isModalOpen = false;
const accountViews = new Map(); // accountId -> View instance

// Current view bounds synced from renderer placeholder
let currentViewBounds = { x: 72, y: 44, width: 1208, height: 756 };

/**
 * Load persistent account data or seed default accounts
 */
function loadAccounts() {
  try {
    if (fs.existsSync(ACCOUNTS_FILE)) {
      const data = fs.readFileSync(ACCOUNTS_FILE, 'utf8');
      accounts = JSON.parse(data);
    }
  } catch (err) {
    console.error('Failed to load accounts.json, initializing defaults:', err);
  }

  if (!Array.isArray(accounts) || accounts.length === 0) {
    accounts = [
      { id: 'acc_personal', name: 'Personal', color: '#ff0000', partition: 'persist:account_acc_personal', created: Date.now() },
      { id: 'acc_work', name: 'Work', color: '#3ea6ff', partition: 'persist:account_acc_work', created: Date.now() + 1 },
      { id: 'acc_gaming', name: 'Gaming', color: '#a855f7', partition: 'persist:account_acc_gaming', created: Date.now() + 2 },
      { id: 'acc_music', name: 'Music', color: '#2ba640', partition: 'persist:account_acc_music', created: Date.now() + 3 }
    ];
    saveAccounts();
  }

  if (!activeAccountId && accounts.length > 0) {
    activeAccountId = accounts[0].id;
  }
}

/**
 * Save accounts metadata to disk
 */
function saveAccounts() {
  try {
    fs.writeFileSync(ACCOUNTS_FILE, JSON.stringify(accounts, null, 2), 'utf8');
  } catch (err) {
    console.error('Failed to save accounts to disk:', err);
  }
}

/**
 * Unified View Wrapper
 */
class AccountViewWrapper {
  constructor(account) {
    this.account = account;
    this.isWebContentsView = typeof WebContentsView !== 'undefined';
    this.isLoaded = false;
    
    // Configure session partition
    const ses = session.fromPartition(account.partition);
    ses.setUserAgent(DESKTOP_USER_AGENT);

    // Permission handling
    ses.setPermissionRequestHandler((webContents, permission, callback) => {
      const allowed = ['notifications', 'fullscreen', 'media'];
      callback(allowed.includes(permission));
    });

    const webPreferences = {
      session: ses,
      sandbox: true,
      contextIsolation: true,
      nodeIntegration: false,
      allowRunningInsecureContent: false,
      backgroundThrottling: true,
      preload: path.join(__dirname, 'preload.js')
    };

    if (this.isWebContentsView) {
      this.view = new WebContentsView({ webPreferences });
      this.webContents = this.view.webContents;
    } else {
      this.view = new BrowserView({ webPreferences });
      this.webContents = this.view.webContents;
      this.view.setAutoResize({ width: true, height: true, horizontal: true, vertical: true });
    }

    this.webContents.setUserAgent(DESKTOP_USER_AGENT);
    this.setupEvents();
  }

  setupEvents() {
    this.webContents.setWindowOpenHandler(({ url }) => {
      if (!url.includes('youtube.com') && !url.includes('accounts.google.com') && !url.includes('google.com')) {
        shell.openExternal(url);
        return { action: 'deny' };
      }
      return { action: 'allow' };
    });

    this.webContents.on('will-navigate', (event, url) => {
      if (!url.includes('youtube.com') && !url.includes('accounts.google.com') && !url.includes('google.com')) {
        event.preventDefault();
        shell.openExternal(url);
      }
    });

    this.webContents.on('did-finish-load', () => {
      this.isLoaded = true;
      notifyRendererState(this.account.id);
    });

    this.webContents.on('page-title-updated', (event, title) => {
      if (activeAccountId === this.account.id && mainWindow) {
        mainWindow.webContents.send('page:title-updated', { accountId: this.account.id, title });
      }
    });

    this.webContents.on('did-fail-load', (event, errorCode, errorDescription, validatedURL, isMainFrame) => {
      if (isMainFrame && errorCode !== -3) {
        if (mainWindow) {
          mainWindow.webContents.send('page:load-error', {
            accountId: this.account.id,
            errorCode,
            errorDescription,
            url: validatedURL
          });
        }
      }
    });
  }

  load(url = 'https://www.youtube.com') {
    if (!this.isLoaded) {
      this.webContents.loadURL(url);
    }
  }

  attach(win) {
    if (isModalOpen) return; // Don't attach while modal is open
    if (this.isWebContentsView) {
      win.contentView.addChildView(this.view);
      this.view.setBounds(currentViewBounds);
    } else {
      win.setBrowserView(this.view);
      this.view.setBounds(currentViewBounds);
    }
    this.webContents.focus();
  }

  detach(win) {
    if (this.isWebContentsView) {
      try {
        win.contentView.removeChildView(this.view);
      } catch (e) {}
    } else {
      if (win.getBrowserView() === this.view) {
        win.setBrowserView(null);
      }
    }
  }

  updateBounds(bounds) {
    if (bounds && bounds.width > 0 && bounds.height > 0) {
      this.view.setBounds(bounds);
    }
  }

  destroy(win) {
    this.detach(win);
    if (this.webContents && !this.webContents.isDestroyed()) {
      this.webContents.close();
    }
  }
}

/**
 * Get or initialize view instance
 */
function getOrCreateAccountView(account) {
  if (!accountViews.has(account.id)) {
    const viewWrapper = new AccountViewWrapper(account);
    viewWrapper.load('https://www.youtube.com');
    accountViews.set(account.id, viewWrapper);
  }
  return accountViews.get(account.id);
}

/**
 * Switch active account view
 */
function switchAccount(accountId) {
  const targetAccount = accounts.find(a => a.id === accountId);
  if (!targetAccount || !mainWindow) return;

  if (activeAccountId && accountViews.has(activeAccountId)) {
    const currentView = accountViews.get(activeAccountId);
    currentView.detach(mainWindow);
  }

  activeAccountId = accountId;
  const newView = getOrCreateAccountView(targetAccount);
  if (!isModalOpen) {
    newView.attach(mainWindow);
  }

  notifyRendererState(accountId);
}

/**
 * Notify renderer process of state changes
 */
function notifyRendererState(accountId) {
  if (!mainWindow || accountId !== activeAccountId) return;
  const viewWrapper = accountViews.get(accountId);
  if (!viewWrapper) return;

  const wc = viewWrapper.webContents;
  mainWindow.webContents.send('page:state-changed', {
    accountId,
    canGoBack: wc.canGoBack(),
    canGoForward: wc.canGoForward(),
    url: wc.getURL(),
    title: wc.getTitle()
  });
}

/**
 * Create Main BrowserWindow
 */
function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    title: 'TubeMulti',
    icon: path.join(__dirname, 'assets', 'icon.png'),
    backgroundColor: '#0f0f0f',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'src', 'index.html'));

  const handleResize = () => {
    if (!isModalOpen && activeAccountId && accountViews.has(activeAccountId)) {
      accountViews.get(activeAccountId).updateBounds(currentViewBounds);
    }
  };

  mainWindow.on('resize', handleResize);
  mainWindow.on('maximize', handleResize);
  mainWindow.on('unmaximize', handleResize);
  mainWindow.on('enter-full-screen', handleResize);
  mainWindow.on('leave-full-screen', handleResize);

  mainWindow.on('closed', () => {
    mainWindow = null;
    accountViews.clear();
  });
}

/**
 * Register IPC Handlers
 */
function registerIpcHandlers() {
  // Toggle WebContentsView visibility when HTML Modals open/close
  ipcMain.on('modal:set-state', (event, isOpen) => {
    isModalOpen = !!isOpen;
    if (!mainWindow) return;

    if (activeAccountId && accountViews.has(activeAccountId)) {
      const activeView = accountViews.get(activeAccountId);
      if (isModalOpen) {
        activeView.detach(mainWindow);
      } else {
        activeView.attach(mainWindow);
      }
    }
  });

  // Sync view bounds from renderer ResizeObserver
  ipcMain.on('view:update-bounds', (event, bounds) => {
    if (bounds && bounds.width > 0 && bounds.height > 0) {
      currentViewBounds = bounds;
      if (!isModalOpen && activeAccountId && accountViews.has(activeAccountId)) {
        accountViews.get(activeAccountId).updateBounds(currentViewBounds);
      }
    }
  });

  // Native Context Menu for Profile Actions
  ipcMain.on('context-menu:show-account', (event, accountId) => {
    const acc = accounts.find(a => a.id === accountId);
    if (!acc || !mainWindow) return;

    const template = [
      {
        label: `Edit "${acc.name}"`,
        click: () => mainWindow.webContents.send('menu:trigger-edit', accountId)
      },
      {
        label: 'Hibernate Tab',
        enabled: accountId !== activeAccountId,
        click: () => {
          if (accountViews.has(accountId)) {
            accountViews.get(accountId).destroy(mainWindow);
            accountViews.delete(accountId);
          }
          mainWindow.webContents.send('menu:trigger-hibernated', accountId);
        }
      },
      { type: 'separator' },
      {
        label: 'Delete Profile',
        enabled: accounts.length > 1,
        click: () => mainWindow.webContents.send('menu:trigger-delete', accountId)
      }
    ];

    const menu = Menu.buildFromTemplate(template);
    menu.popup({ window: mainWindow });
  });

  ipcMain.handle('accounts:get', () => {
    return { accounts, activeAccountId };
  });

  ipcMain.handle('accounts:add', (event, { name, color }) => {
    const id = 'acc_' + Date.now();
    const partition = `persist:account_${id}`;
    const newAccount = {
      id,
      name: name || `Profile ${accounts.length + 1}`,
      color: color || '#3ea6ff',
      partition,
      created: Date.now()
    };

    accounts.push(newAccount);
    saveAccounts();

    switchAccount(id);
    return { accounts, activeAccountId };
  });

  ipcMain.handle('accounts:switch', (event, accountId) => {
    switchAccount(accountId);
    return { accounts, activeAccountId };
  });

  ipcMain.handle('accounts:remove', (event, accountId) => {
    if (accounts.length <= 1) {
      throw new Error('You must keep at least one profile.');
    }

    const index = accounts.findIndex(a => a.id === accountId);
    if (index !== -1) {
      if (accountViews.has(accountId)) {
        const viewWrapper = accountViews.get(accountId);
        if (mainWindow) viewWrapper.destroy(mainWindow);
        accountViews.delete(accountId);
      }

      accounts.splice(index, 1);
      saveAccounts();

      if (activeAccountId === accountId) {
        switchAccount(accounts[0].id);
      }
    }
    return { accounts, activeAccountId };
  });

  ipcMain.handle('accounts:update', (event, { accountId, name, color }) => {
    const acc = accounts.find(a => a.id === accountId);
    if (acc) {
      if (name) acc.name = name;
      if (color) acc.color = color;
      saveAccounts();
    }
    return { accounts, activeAccountId };
  });

  ipcMain.handle('accounts:hibernate', (event, accountId) => {
    if (accountId === activeAccountId) {
      throw new Error('Cannot hibernate active tab.');
    }
    if (accountViews.has(accountId)) {
      const viewWrapper = accountViews.get(accountId);
      if (mainWindow) viewWrapper.destroy(mainWindow);
      accountViews.delete(accountId);
    }
    return { accounts, activeAccountId, hibernatedId: accountId };
  });

  ipcMain.handle('app:get-memory', () => {
    const mem = process.memoryUsage();
    return {
      rssMB: Math.round(mem.rss / (1024 * 1024)),
      heapMB: Math.round(mem.heapUsed / (1024 * 1024))
    };
  });

  // Navigation handlers
  ipcMain.handle('nav:back', () => {
    if (activeAccountId && accountViews.has(activeAccountId)) {
      const wc = accountViews.get(activeAccountId).webContents;
      if (wc.canGoBack()) wc.goBack();
    }
  });

  ipcMain.handle('nav:forward', () => {
    if (activeAccountId && accountViews.has(activeAccountId)) {
      const wc = accountViews.get(activeAccountId).webContents;
      if (wc.canGoForward()) wc.goForward();
    }
  });

  ipcMain.handle('nav:reload', () => {
    if (activeAccountId && accountViews.has(activeAccountId)) {
      accountViews.get(activeAccountId).webContents.reload();
    }
  });

  ipcMain.handle('nav:home', () => {
    if (activeAccountId && accountViews.has(activeAccountId)) {
      accountViews.get(activeAccountId).webContents.loadURL('https://www.youtube.com');
    }
  });
}

// App lifecycle
app.whenReady().then(() => {
  loadAccounts();
  registerIpcHandlers();
  createMainWindow();

  mainWindow.webContents.once('did-finish-load', () => {
    if (activeAccountId) {
      switchAccount(activeAccountId);
    }
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createMainWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
