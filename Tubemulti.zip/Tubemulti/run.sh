#!/usr/bin/env bash
# TubeMulti One-Click Launcher for Fedora Linux

# Get absolute path of script directory
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
cd "$DIR" || exit 1

# Check if node_modules exists, install if missing
if [ ! -d "node_modules" ]; then
    echo "First-time setup: Installing dependencies..."
    npm install
fi

# Launch application
echo "Starting TubeMulti..."
npm start
