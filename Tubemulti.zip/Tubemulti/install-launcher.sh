#!/usr/bin/env bash
# TubeMulti Desktop Launcher Installer for Fedora Linux

PROJECT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
RUN_SCRIPT="$PROJECT_DIR/run.sh"
ICON_PATH="$PROJECT_DIR/assets/icon.png"
APPS_DIR="$HOME/.local/share/applications"
DESKTOP_DIR="$HOME/Desktop"

# Ensure run.sh is executable
chmod +x "$RUN_SCRIPT"

# Make sure applications directory exists
mkdir -p "$APPS_DIR"

DESKTOP_FILE="$APPS_DIR/TubeMulti.desktop"

# Create .desktop file for system application menu
cat <<EOF > "$DESKTOP_FILE"
[Desktop Entry]
Type=Application
Name=TubeMulti
Comment=Multi-Account YouTube Desktop Client
Exec="$RUN_SCRIPT"
Icon=$ICON_PATH
Terminal=false
Categories=AudioVideo;Video;Network;
StartupWMClass=TubeMulti
EOF

chmod +x "$DESKTOP_FILE"

# If Desktop folder exists, also place a desktop shortcut there
if [ -d "$DESKTOP_DIR" ]; then
    cp "$DESKTOP_FILE" "$DESKTOP_DIR/TubeMulti.desktop"
    chmod +x "$DESKTOP_DIR/TubeMulti.desktop"
    # Allow launching on GNOME Desktop if gio is available
    if command -v gio &> /dev/null; then
        gio set "$DESKTOP_DIR/TubeMulti.desktop" metadata::trusted true 2>/dev/null || true
    fi
fi

# Update desktop database cache
if command -v update-desktop-database &> /dev/null; then
    update-desktop-database "$APPS_DIR" 2>/dev/null || true
fi

echo "================================================="
echo " TubeMulti Desktop Launcher Installed Successfully!"
echo "================================================="
echo "You can now open TubeMulti:"
echo " 1. From your Fedora Application Menu / Activities (search 'TubeMulti')"
echo " 2. By double-clicking the desktop icon (if present)"
echo " 3. Or by running: ./run.sh"
echo "================================================="
