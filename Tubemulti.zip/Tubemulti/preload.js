/**
 * TubeMulti Preload Script
 * ContextBridge exposing secure IPC methods to renderer process
 */

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  // Modal Layering & Layout Sync
  setModalState: (isOpen) => ipcRenderer.send('modal:set-state', isOpen),
  updateViewBounds: (bounds) => ipcRenderer.send('view:update-bounds', bounds),
  showAccountContextMenu: (accountId) => ipcRenderer.send('context-menu:show-account', accountId),

  // Account Management
  getAccounts: () => ipcRenderer.invoke('accounts:get'),
  addAccount: (data) => ipcRenderer.invoke('accounts:add', data),
  switchAccount: (accountId) => ipcRenderer.invoke('accounts:switch', accountId),
  removeAccount: (accountId) => ipcRenderer.invoke('accounts:remove', accountId),
  updateAccount: (data) => ipcRenderer.invoke('accounts:update', data),
  hibernateAccount: (accountId) => ipcRenderer.invoke('accounts:hibernate', accountId),

  // Diagnostics & Memory
  getMemoryStats: () => ipcRenderer.invoke('app:get-memory'),

  // Web View Navigation
  navigateBack: () => ipcRenderer.invoke('nav:back'),
  navigateForward: () => ipcRenderer.invoke('nav:forward'),
  reloadPage: () => ipcRenderer.invoke('nav:reload'),
  navigateHome: () => ipcRenderer.invoke('nav:home'),

  // Native Menu Callbacks
  onTriggerEdit: (callback) => {
    const handler = (event, id) => callback(id);
    ipcRenderer.on('menu:trigger-edit', handler);
    return () => ipcRenderer.removeListener('menu:trigger-edit', handler);
  },

  onTriggerHibernated: (callback) => {
    const handler = (event, id) => callback(id);
    ipcRenderer.on('menu:trigger-hibernated', handler);
    return () => ipcRenderer.removeListener('menu:trigger-hibernated', handler);
  },

  onTriggerDelete: (callback) => {
    const handler = (event, id) => callback(id);
    ipcRenderer.on('menu:trigger-delete', handler);
    return () => ipcRenderer.removeListener('menu:trigger-delete', handler);
  },

  // Main -> Renderer Event Listeners
  onPageStateChanged: (callback) => {
    const handler = (event, data) => callback(data);
    ipcRenderer.on('page:state-changed', handler);
    return () => ipcRenderer.removeListener('page:state-changed', handler);
  },

  onPageTitleUpdated: (callback) => {
    const handler = (event, data) => callback(data);
    ipcRenderer.on('page:title-updated', handler);
    return () => ipcRenderer.removeListener('page:title-updated', handler);
  },

  onPageLoadError: (callback) => {
    const handler = (event, data) => callback(data);
    ipcRenderer.on('page:load-error', handler);
    return () => ipcRenderer.removeListener('page:load-error', handler);
  }
});
