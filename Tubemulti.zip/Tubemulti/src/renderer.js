/**
 * TubeMulti Renderer Process Script
 * Frictionless multi-account creation, modal layering sync & native context menu integration.
 */

document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements
  const accountListContainer = document.getElementById('account-list');
  const activeProfileName = document.getElementById('active-profile-name');
  const activeProfileBadge = document.getElementById('active-profile-badge');
  const ramBadge = document.getElementById('ram-badge');
  const viewPlaceholder = document.getElementById('view-placeholder');

  // Navigation Controls
  const btnBack = document.getElementById('btn-back');
  const btnForward = document.getElementById('btn-forward');
  const btnReload = document.getElementById('btn-reload');
  const btnHome = document.getElementById('btn-home');

  // Status & Errors
  const statusDot = document.getElementById('status-dot');
  const statusText = document.getElementById('status-text');
  const errorBanner = document.getElementById('error-banner');
  const errorMessage = document.getElementById('error-message');
  const btnErrorRetry = document.getElementById('btn-error-retry');

  // Add Account Modal
  const btnAddAccount = document.getElementById('btn-add-account');
  const addAccountModal = document.getElementById('add-account-modal');
  const presetsGrid = document.getElementById('presets-grid');
  const accountNameInput = document.getElementById('account-name-input');
  const colorPalette = document.getElementById('color-palette');
  const btnModalCancel = document.getElementById('btn-modal-cancel');
  const btnModalSave = document.getElementById('btn-modal-save');

  // Edit Account Modal
  const editAccountModal = document.getElementById('edit-account-modal');
  const editNameInput = document.getElementById('edit-name-input');
  const editColorPalette = document.getElementById('edit-color-palette');
  const btnEditCancel = document.getElementById('btn-edit-cancel');
  const btnEditSave = document.getElementById('btn-edit-save');

  // Application State
  let currentAccounts = [];
  let currentActiveId = null;
  let hibernatedAccountIds = new Set();
  let selectedColor = '#ff0000';
  let editSelectedColor = '#ff0000';
  let editTargetAccountId = null;

  // View Bounds Synchronization
  function sendBoundsUpdate() {
    if (!viewPlaceholder) return;
    const rect = viewPlaceholder.getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0) {
      window.electronAPI.updateViewBounds({
        x: Math.round(rect.left),
        y: Math.round(rect.top),
        width: Math.round(rect.width),
        height: Math.round(rect.height)
      });
    }
  }

  const resizeObserver = new ResizeObserver(() => {
    sendBoundsUpdate();
  });
  if (viewPlaceholder) {
    resizeObserver.observe(viewPlaceholder);
  }
  window.addEventListener('resize', sendBoundsUpdate);

  // Initialize
  async function init() {
    try {
      const data = await window.electronAPI.getAccounts();
      currentAccounts = data.accounts;
      currentActiveId = data.activeAccountId;
      renderAccountList();
      updateTopBarProfileInfo();
      startMemoryMonitoring();
      setTimeout(sendBoundsUpdate, 50);
    } catch (err) {
      console.error('Failed to initialize accounts:', err);
    }
  }

  // Render Account List
  function renderAccountList() {
    accountListContainer.innerHTML = '';

    currentAccounts.forEach((acc, index) => {
      const isHibernated = hibernatedAccountIds.has(acc.id);
      const isActive = acc.id === currentActiveId;

      const wrapper = document.createElement('div');
      wrapper.className = `account-item-wrapper ${isActive ? 'active' : ''} ${isHibernated ? 'hibernated' : ''}`;
      wrapper.dataset.id = acc.id;

      const pill = document.createElement('div');
      pill.className = 'active-pill';

      const avatar = document.createElement('div');
      avatar.className = 'account-avatar';
      avatar.style.backgroundColor = acc.color || '#ff0000';
      avatar.innerText = (acc.name || 'A').charAt(0).toUpperCase();

      if (index < 9) {
        const indexBadge = document.createElement('span');
        indexBadge.className = 'account-index-badge';
        indexBadge.innerText = index + 1;
        avatar.appendChild(indexBadge);
      }

      const tooltip = document.createElement('div');
      tooltip.className = 'account-tooltip';
      tooltip.innerText = `${acc.name}${index < 9 ? ` (Ctrl+${index + 1})` : ''}${isHibernated ? ' [Hibernated]' : ''}`;

      wrapper.appendChild(pill);
      wrapper.appendChild(avatar);
      wrapper.appendChild(tooltip);

      // Switch Account Click
      wrapper.addEventListener('click', async () => {
        if (acc.id === currentActiveId && !isHibernated) return;
        hibernatedAccountIds.delete(acc.id);
        try {
          const res = await window.electronAPI.switchAccount(acc.id);
          currentAccounts = res.accounts;
          currentActiveId = res.activeAccountId;
          renderAccountList();
          updateTopBarProfileInfo();
          setTimeout(sendBoundsUpdate, 50);
        } catch (err) {
          console.error('Failed to switch account:', err);
        }
      });

      // Right Click -> Native Context Menu
      wrapper.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        window.electronAPI.showAccountContextMenu(acc.id);
      });

      accountListContainer.appendChild(wrapper);
    });
  }

  // Top Bar Profile Info
  function updateTopBarProfileInfo() {
    const activeAccount = currentAccounts.find(a => a.id === currentActiveId);
    if (activeAccount) {
      activeProfileName.innerText = activeAccount.name;
      activeProfileBadge.style.backgroundColor = activeAccount.color || '#ff0000';
    }
  }

  // Memory Usage Monitor
  async function startMemoryMonitoring() {
    const updateMem = async () => {
      try {
        const stats = await window.electronAPI.getMemoryStats();
        if (stats && ramBadge) {
          ramBadge.innerText = `RAM: ${stats.rssMB} MB`;
        }
      } catch (e) {}
    };
    updateMem();
    setInterval(updateMem, 5000);
  }

  // Add Account Modal Management
  presetsGrid.addEventListener('click', (e) => {
    if (e.target.classList.contains('preset-chip')) {
      const name = e.target.dataset.name;
      const color = e.target.dataset.color;
      accountNameInput.value = name;
      selectedColor = color;
      updateSelectedSwatch(colorPalette, selectedColor);
    }
  });

  function openAddAccountModal() {
    accountNameInput.value = '';
    selectedColor = '#ff0000';
    updateSelectedSwatch(colorPalette, selectedColor);
    addAccountModal.classList.add('open');
    window.electronAPI.setModalState(true);
    accountNameInput.focus();
  }

  function closeAddAccountModal() {
    addAccountModal.classList.remove('open');
    window.electronAPI.setModalState(false);
  }

  function updateSelectedSwatch(container, targetColor) {
    const swatches = container.querySelectorAll('.color-swatch');
    swatches.forEach(swatch => {
      if (swatch.dataset.color === targetColor) {
        swatch.classList.add('selected');
      } else {
        swatch.classList.remove('selected');
      }
    });
  }

  colorPalette.addEventListener('click', (e) => {
    if (e.target.classList.contains('color-swatch')) {
      selectedColor = e.target.dataset.color;
      updateSelectedSwatch(colorPalette, selectedColor);
    }
  });

  btnAddAccount.addEventListener('click', openAddAccountModal);
  btnModalCancel.addEventListener('click', closeAddAccountModal);

  btnModalSave.addEventListener('click', async () => {
    const name = accountNameInput.value.trim() || `Profile ${currentAccounts.length + 1}`;
    try {
      const res = await window.electronAPI.addAccount({ name, color: selectedColor });
      currentAccounts = res.accounts;
      currentActiveId = res.activeAccountId;
      renderAccountList();
      updateTopBarProfileInfo();
      closeAddAccountModal();
      setTimeout(sendBoundsUpdate, 50);
    } catch (err) {
      console.error('Failed to create account:', err);
    }
  });

  accountNameInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') btnModalSave.click();
    if (e.key === 'Escape') closeAddAccountModal();
  });

  // Edit Account Modal Management
  function openEditAccountModal(acc) {
    editTargetAccountId = acc.id;
    editNameInput.value = acc.name;
    editSelectedColor = acc.color || '#ff0000';
    updateSelectedSwatch(editColorPalette, editSelectedColor);
    editAccountModal.classList.add('open');
    window.electronAPI.setModalState(true);
    editNameInput.focus();
  }

  function closeEditAccountModal() {
    editAccountModal.classList.remove('open');
    window.electronAPI.setModalState(false);
    editTargetAccountId = null;
  }

  editColorPalette.addEventListener('click', (e) => {
    if (e.target.classList.contains('color-swatch')) {
      editSelectedColor = e.target.dataset.color;
      updateSelectedSwatch(editColorPalette, editSelectedColor);
    }
  });

  btnEditCancel.addEventListener('click', closeEditAccountModal);

  btnEditSave.addEventListener('click', async () => {
    if (!editTargetAccountId) return;
    const name = editNameInput.value.trim();
    try {
      const res = await window.electronAPI.updateAccount({
        accountId: editTargetAccountId,
        name: name || undefined,
        color: editSelectedColor
      });
      currentAccounts = res.accounts;
      renderAccountList();
      updateTopBarProfileInfo();
      closeEditAccountModal();
    } catch (err) {
      console.error('Failed to update profile:', err);
    }
  });

  // Native Context Menu Callbacks
  window.electronAPI.onTriggerEdit((accountId) => {
    const acc = currentAccounts.find(a => a.id === accountId);
    if (acc) openEditAccountModal(acc);
  });

  window.electronAPI.onTriggerHibernated((accountId) => {
    hibernatedAccountIds.add(accountId);
    renderAccountList();
  });

  window.electronAPI.onTriggerDelete(async (accountId) => {
    if (currentAccounts.length <= 1) {
      alert('You must keep at least one profile.');
      return;
    }
    const acc = currentAccounts.find(a => a.id === accountId);
    const confirmed = confirm(`Are you sure you want to delete profile "${acc?.name}"?`);
    if (confirmed) {
      try {
        const res = await window.electronAPI.removeAccount(accountId);
        currentAccounts = res.accounts;
        currentActiveId = res.activeAccountId;
        hibernatedAccountIds.delete(accountId);
        renderAccountList();
        updateTopBarProfileInfo();
        setTimeout(sendBoundsUpdate, 50);
      } catch (err) {
        alert(err.message || 'Failed to remove account');
      }
    }
  });

  // Keyboard Shortcuts (Ctrl+1..9, Ctrl+N, Ctrl+R)
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey) {
      if (e.key >= '1' && e.key <= '9') {
        const index = parseInt(e.key, 10) - 1;
        if (index < currentAccounts.length) {
          const targetAcc = currentAccounts[index];
          window.electronAPI.switchAccount(targetAcc.id).then(res => {
            currentAccounts = res.accounts;
            currentActiveId = res.activeAccountId;
            hibernatedAccountIds.delete(targetAcc.id);
            renderAccountList();
            updateTopBarProfileInfo();
            setTimeout(sendBoundsUpdate, 50);
          });
        }
      } else if (e.key.toLowerCase() === 'n') {
        e.preventDefault();
        openAddAccountModal();
      } else if (e.key.toLowerCase() === 'r') {
        e.preventDefault();
        window.electronAPI.reloadPage();
      }
    }
  });

  // Navigation Button Listeners
  btnBack.addEventListener('click', () => window.electronAPI.navigateBack());
  btnForward.addEventListener('click', () => window.electronAPI.navigateForward());
  btnReload.addEventListener('click', () => window.electronAPI.reloadPage());
  btnHome.addEventListener('click', () => window.electronAPI.navigateHome());

  btnErrorRetry.addEventListener('click', () => {
    errorBanner.style.display = 'none';
    window.electronAPI.reloadPage();
  });

  // Main Process Event Listeners
  window.electronAPI.onPageStateChanged((data) => {
    if (data.accountId === currentActiveId) {
      btnBack.disabled = !data.canGoBack;
      btnForward.disabled = !data.canGoForward;
      errorBanner.style.display = 'none';
    }
  });

  window.electronAPI.onPageTitleUpdated((data) => {
    if (data.accountId === currentActiveId && data.title) {
      document.title = `${data.title} - TubeMulti`;
    }
  });

  window.electronAPI.onPageLoadError((data) => {
    if (data.accountId === currentActiveId) {
      errorMessage.innerText = `Load Error (${data.errorCode}): ${data.errorDescription || 'Could not connect to YouTube.'}`;
      errorBanner.style.display = 'flex';
    }
  });

  // Network Connectivity Indicators
  function updateOnlineStatus() {
    if (navigator.onLine) {
      statusDot.classList.remove('offline');
      statusText.innerText = 'Connected';
      errorBanner.style.display = 'none';
    } else {
      statusDot.classList.add('offline');
      statusText.innerText = 'Offline';
      errorMessage.innerText = 'No Internet Connection. Please check your network status.';
      errorBanner.style.display = 'flex';
    }
  }

  window.addEventListener('online', updateOnlineStatus);
  window.addEventListener('offline', updateOnlineStatus);

  // Initial Run
  init();
  updateOnlineStatus();
});
